<?php
/**
 * Created by PhpStorm.
 * User: MrShyAm
 * Date: 6/21/2017
 * Time: 11:16 AM
 */
echo "privacy";
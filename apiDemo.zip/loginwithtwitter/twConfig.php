<?php
if(!session_id()){
    session_start();
}

//Include Twitter client library 
include_once 'src/twitteroauth.php';

/*
 * Configuration and setup Twitter API
 */
$consumerKey = '';
$consumerSecret = '';
$redirectURL = 'http://localhost/apiDemo/loginwithtwitter/';

?>